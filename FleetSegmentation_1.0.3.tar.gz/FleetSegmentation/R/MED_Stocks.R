#'@docType data
#'
#'@title Stock data of the Mediterranean
#'
#'@description A dataset containing the stock identifiers for fish species and GSA catch areas of the Mediterranean.
#' Created by Erik Sulanke, Thuenen-Institute for Sea Fisheries, Bremerhaven, Germany, in September 2020. Based on validated stock assessment forms of the
#' General Fisheries Commission for the Mediterranean - GFCM (http://www.fao.org/gfcm/data/safs/en/).
#'
#'@keywords datasets
#'
#'@format A data frame with 80 rows and 3 variables:
#' \describe{
#'  \item{species_code}{(Three-letter ICES species code}
#'  \item{GSA}{FAO area code for GSA areas}
#'  \item{stock}{Stock code, comprising species and area codes}
#' }
"MED_stocks"
